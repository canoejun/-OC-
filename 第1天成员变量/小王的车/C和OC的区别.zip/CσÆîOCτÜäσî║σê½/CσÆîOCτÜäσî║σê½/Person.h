//
//  Person.h
//  C和OC的区别
//
//  Created by PengXiaodong on 2018/7/25.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject{
    //成员变量 属性 存储数据
    //临时变量就直接放在操作的位置
    //整个对象存在的时候就需要保存的数据 定义：成员变量
    //这个变量相对于这个类的某个对象而言 是全局变量
    
    /*
    //默认情况下 成员变量外部是无法访问的 安全
    @private
        //私有的 只能在当前这个类里面访问
        //外部无法访问 子类也无法继承
    @protected
        //默认 受保护的 外部无法访问 子类可以继承
    @public
        //共有的 都可以访问 子类可以继承
    */
    NSString *name; //姓名
    NSInteger age; //年龄
    NSString *address;//地址
}

//行为 方法
//提供给外部使用
//- 实例方法 对象方法 只能用对象去调用的方法
//必须对象存在了 才能去调用这个方法
//有内存了 才能有操作了

//+ 类方法
//无需实例化 直接用这个类去调用的方法
//封装某个类 数据  工具
//类方法是不需要分配内存空间的
//在类方法里面不要去调用这个类里面的成员变量 属性变量 对象方法
+ (void)test;

//设置名字
- (void) setName:(NSString *)aName;
//获取名字
- (NSString *)getName;

//设置年龄
- (void) setAge:(NSInteger)aAge;
//获取年龄
- (NSInteger)getAge;

//同时设置姓名和年龄 地址
- (void) setName:(NSString *)aName andAge:(NSInteger)aAge andAddress:(NSString *)aAddress;

@end














