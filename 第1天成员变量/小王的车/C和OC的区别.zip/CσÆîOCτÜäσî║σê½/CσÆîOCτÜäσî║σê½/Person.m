//
//  Person.m
//  C和OC的区别
//
//  Created by PengXiaodong on 2018/7/25.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import "Person.h"

/*
 ctrl + commond  + 左右键 切换.h .m文件
 alt + commond + 左右键 展开或者收缩一个方法的内容
 */
@implementation Person

- (void)setName:(NSString *)aName{
    name = aName;
}

- (NSString *)getName{
    return name;
}

- (void)setAge:(NSInteger)aAge{
    age = aAge;
}

- (NSInteger)getAge{
    return age;
}

- (void)setName:(NSString *)aName andAge:(NSInteger)aAge andAddress:(NSString *)aAddress{
    name = aName;
    age = aAge;
    address = aAddress;
}

+ (void)test{
    //NSLog(@"name = %@", name);
    //[self setName:@"jack"];
}

@end











