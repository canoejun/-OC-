//
//  main.m
//  C和OC的区别
//
//  Created by PengXiaodong on 2018/7/24.
//  Copyright © 2018年 PengXiaodong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[]) {
    
    //创建对象 实例化某个类
    Person *zs = [[Person alloc] init];
    Person *ls = [[Person alloc] init];
    
    //无法直接访问成员变量
    //zs.name = @"jack"; //错误 无法访问
    //zs->age = 20; public 修饰的变量
    [zs setName:@"张三"];
    [ls setName:@"李四"];
    
    //为什么需要类 抽象出来一个东西 类（多种数据类型 多个方法）
    [Person test];
    
    
    
    小王  有一辆黑色的奥迪A8 轿车
    Person:name car
    Car-:color bank type
    
    请告诉我小王有辆什么牌子的车
    
    成员变量
    属性变量
    点语法
    自定义init方法
    
    return 0;
}













